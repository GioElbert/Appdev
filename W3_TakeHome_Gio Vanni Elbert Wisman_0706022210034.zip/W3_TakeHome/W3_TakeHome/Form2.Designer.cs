﻿namespace W3_TakeHome
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBackColor = new System.Windows.Forms.Label();
            this.lblTextColor = new System.Windows.Forms.Label();
            this.radioRed = new System.Windows.Forms.RadioButton();
            this.radioGreen = new System.Windows.Forms.RadioButton();
            this.radioYellow = new System.Windows.Forms.RadioButton();
            this.radioBlue = new System.Windows.Forms.RadioButton();
            this.radioOrange = new System.Windows.Forms.RadioButton();
            this.radioRedText = new System.Windows.Forms.RadioButton();
            this.radioBlueText = new System.Windows.Forms.RadioButton();
            this.radioGreenText = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.checkAgree2 = new System.Windows.Forms.CheckBox();
            this.checkChoice2 = new System.Windows.Forms.CheckBox();
            this.labelAgree2 = new System.Windows.Forms.Label();
            this.lbChoice2 = new System.Windows.Forms.Label();
            this.btnMagic = new System.Windows.Forms.Button();
            this.lbHimyname = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblBackColor
            // 
            this.lblBackColor.AutoSize = true;
            this.lblBackColor.Location = new System.Drawing.Point(23, 26);
            this.lblBackColor.Name = "lblBackColor";
            this.lblBackColor.Size = new System.Drawing.Size(233, 16);
            this.lblBackColor.TabIndex = 0;
            this.lblBackColor.Text = "Pick Your Favorite Background Color :";
            // 
            // lblTextColor
            // 
            this.lblTextColor.AutoSize = true;
            this.lblTextColor.Location = new System.Drawing.Point(23, 142);
            this.lblTextColor.Name = "lblTextColor";
            this.lblTextColor.Size = new System.Drawing.Size(103, 16);
            this.lblTextColor.TabIndex = 1;
            this.lblTextColor.Text = "Pick Text Color :";
            // 
            // radioRed
            // 
            this.radioRed.AutoSize = true;
            this.radioRed.Checked = true;
            this.radioRed.Location = new System.Drawing.Point(3, 12);
            this.radioRed.Name = "radioRed";
            this.radioRed.Size = new System.Drawing.Size(54, 20);
            this.radioRed.TabIndex = 2;
            this.radioRed.TabStop = true;
            this.radioRed.Text = "Red";
            this.radioRed.UseVisualStyleBackColor = true;
            this.radioRed.CheckedChanged += new System.EventHandler(this.radioRed_CheckedChanged);
            // 
            // radioGreen
            // 
            this.radioGreen.AutoSize = true;
            this.radioGreen.Location = new System.Drawing.Point(3, 38);
            this.radioGreen.Name = "radioGreen";
            this.radioGreen.Size = new System.Drawing.Size(65, 20);
            this.radioGreen.TabIndex = 3;
            this.radioGreen.Text = "Green";
            this.radioGreen.UseVisualStyleBackColor = true;
            // 
            // radioYellow
            // 
            this.radioYellow.AutoSize = true;
            this.radioYellow.Location = new System.Drawing.Point(3, 64);
            this.radioYellow.Name = "radioYellow";
            this.radioYellow.Size = new System.Drawing.Size(68, 20);
            this.radioYellow.TabIndex = 4;
            this.radioYellow.Text = "Yellow";
            this.radioYellow.UseVisualStyleBackColor = true;
            // 
            // radioBlue
            // 
            this.radioBlue.AutoSize = true;
            this.radioBlue.Location = new System.Drawing.Point(120, 12);
            this.radioBlue.Name = "radioBlue";
            this.radioBlue.Size = new System.Drawing.Size(55, 20);
            this.radioBlue.TabIndex = 5;
            this.radioBlue.Text = "Blue";
            this.radioBlue.UseVisualStyleBackColor = true;
            // 
            // radioOrange
            // 
            this.radioOrange.AutoSize = true;
            this.radioOrange.Location = new System.Drawing.Point(120, 38);
            this.radioOrange.Name = "radioOrange";
            this.radioOrange.Size = new System.Drawing.Size(73, 20);
            this.radioOrange.TabIndex = 6;
            this.radioOrange.Text = "Orange";
            this.radioOrange.UseVisualStyleBackColor = true;
            // 
            // radioRedText
            // 
            this.radioRedText.AutoSize = true;
            this.radioRedText.Checked = true;
            this.radioRedText.Location = new System.Drawing.Point(13, 21);
            this.radioRedText.Name = "radioRedText";
            this.radioRedText.Size = new System.Drawing.Size(54, 20);
            this.radioRedText.TabIndex = 7;
            this.radioRedText.TabStop = true;
            this.radioRedText.Text = "Red";
            this.radioRedText.UseVisualStyleBackColor = true;
            // 
            // radioBlueText
            // 
            this.radioBlueText.AutoSize = true;
            this.radioBlueText.Location = new System.Drawing.Point(12, 47);
            this.radioBlueText.Name = "radioBlueText";
            this.radioBlueText.Size = new System.Drawing.Size(55, 20);
            this.radioBlueText.TabIndex = 8;
            this.radioBlueText.Text = "Blue";
            this.radioBlueText.UseVisualStyleBackColor = true;
            // 
            // radioGreenText
            // 
            this.radioGreenText.AutoSize = true;
            this.radioGreenText.Location = new System.Drawing.Point(12, 73);
            this.radioGreenText.Name = "radioGreenText";
            this.radioGreenText.Size = new System.Drawing.Size(65, 20);
            this.radioGreenText.TabIndex = 9;
            this.radioGreenText.Text = "Green";
            this.radioGreenText.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.radioRed);
            this.panel1.Controls.Add(this.radioGreen);
            this.panel1.Controls.Add(this.radioYellow);
            this.panel1.Controls.Add(this.radioBlue);
            this.panel1.Controls.Add(this.radioOrange);
            this.panel1.Location = new System.Drawing.Point(26, 45);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(214, 94);
            this.panel1.TabIndex = 10;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.radioRedText);
            this.panel2.Controls.Add(this.radioBlueText);
            this.panel2.Controls.Add(this.radioGreenText);
            this.panel2.Location = new System.Drawing.Point(17, 161);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 100);
            this.panel2.TabIndex = 11;
            // 
            // checkAgree2
            // 
            this.checkAgree2.AutoSize = true;
            this.checkAgree2.Location = new System.Drawing.Point(26, 267);
            this.checkAgree2.Name = "checkAgree2";
            this.checkAgree2.Size = new System.Drawing.Size(18, 17);
            this.checkAgree2.TabIndex = 12;
            this.checkAgree2.UseVisualStyleBackColor = true;
            this.checkAgree2.CheckedChanged += new System.EventHandler(this.checkAgree2_CheckedChanged);
            // 
            // checkChoice2
            // 
            this.checkChoice2.AutoSize = true;
            this.checkChoice2.Location = new System.Drawing.Point(26, 290);
            this.checkChoice2.Name = "checkChoice2";
            this.checkChoice2.Size = new System.Drawing.Size(18, 17);
            this.checkChoice2.TabIndex = 13;
            this.checkChoice2.UseVisualStyleBackColor = true;
            this.checkChoice2.CheckedChanged += new System.EventHandler(this.checkChoice2_CheckedChanged);
            // 
            // labelAgree2
            // 
            this.labelAgree2.AutoSize = true;
            this.labelAgree2.Location = new System.Drawing.Point(50, 267);
            this.labelAgree2.Name = "labelAgree2";
            this.labelAgree2.Size = new System.Drawing.Size(210, 16);
            this.labelAgree2.TabIndex = 14;
            this.labelAgree2.Text = "I Agree to the Terms of Agreement";
            // 
            // lbChoice2
            // 
            this.lbChoice2.AutoSize = true;
            this.lbChoice2.Location = new System.Drawing.Point(50, 291);
            this.lbChoice2.Name = "lbChoice2";
            this.lbChoice2.Size = new System.Drawing.Size(210, 16);
            this.lbChoice2.TabIndex = 15;
            this.lbChoice2.Text = "All the choice I pick above are true";
            // 
            // btnMagic
            // 
            this.btnMagic.Enabled = false;
            this.btnMagic.Location = new System.Drawing.Point(26, 325);
            this.btnMagic.Name = "btnMagic";
            this.btnMagic.Size = new System.Drawing.Size(75, 23);
            this.btnMagic.TabIndex = 16;
            this.btnMagic.Text = "MAGIC";
            this.btnMagic.UseVisualStyleBackColor = true;
            this.btnMagic.Click += new System.EventHandler(this.btnMagic_Click);
            // 
            // lbHimyname
            // 
            this.lbHimyname.AutoSize = true;
            this.lbHimyname.Location = new System.Drawing.Point(132, 328);
            this.lbHimyname.Name = "lbHimyname";
            this.lbHimyname.Size = new System.Drawing.Size(242, 16);
            this.lbHimyname.TabIndex = 17;
            this.lbHimyname.Text = "Hi, My name is _ and my favorite artist is";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbHimyname);
            this.Controls.Add(this.btnMagic);
            this.Controls.Add(this.lbChoice2);
            this.Controls.Add(this.labelAgree2);
            this.Controls.Add(this.checkChoice2);
            this.Controls.Add(this.checkAgree2);
            this.Controls.Add(this.lblTextColor);
            this.Controls.Add(this.lblBackColor);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBackColor;
        private System.Windows.Forms.Label lblTextColor;
        private System.Windows.Forms.RadioButton radioRed;
        private System.Windows.Forms.RadioButton radioGreen;
        private System.Windows.Forms.RadioButton radioYellow;
        private System.Windows.Forms.RadioButton radioBlue;
        private System.Windows.Forms.RadioButton radioOrange;
        private System.Windows.Forms.RadioButton radioRedText;
        private System.Windows.Forms.RadioButton radioBlueText;
        private System.Windows.Forms.RadioButton radioGreenText;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.CheckBox checkAgree2;
        private System.Windows.Forms.CheckBox checkChoice2;
        private System.Windows.Forms.Label labelAgree2;
        private System.Windows.Forms.Label lbChoice2;
        private System.Windows.Forms.Button btnMagic;
        private System.Windows.Forms.Label lbHimyname;
    }
}