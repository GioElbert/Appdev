﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace W3_TakeHome
{
    public partial class Form1 : Form
    {
        public string bgcolorr, forecolorr;
        public Form1()
        {
            InitializeComponent();
            
           
        }
        public Form1(string bgcolor, string forecolor)
        {
            InitializeComponent();
            this.bgcolorr = bgcolor;
            this.forecolorr = forecolor;

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            
            if (txtNama.Text == "" || txtArtist.Text == "")
            {
                MessageBox.Show(" Mohon Mengisi Semua Teks");
            }
            else
            {
                Form2 form2 = new Form2(txtNama.Text, txtArtist.Text);
                form2.Show();
            }
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(txtNama.Text, txtArtist.Text);
            form2.Show();
        }

        private void checkContent_CheckedChanged(object sender, EventArgs e)
        {
            if (checkContent.Checked)
            {
                btnSubmit.Enabled = true;
            }
            else
            { 
            
                btnSubmit.Enabled = false;
            }
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            if (bgcolorr == "Red")
            {
                this.BackColor = Color.Red;
            }
            else if (bgcolorr == "Green")
            {
                this.BackColor = Color.Green;
            }
            else if (bgcolorr == "Yellow")
            {
                this.BackColor = Color.Yellow;
            }
            else if (bgcolorr == "Blue")
            {
                this.BackColor = Color.Blue;
            }
            else if (bgcolorr == "Orange")
            {
                this.BackColor= Color.Orange;
            }

            if (forecolorr == "red")
            {
                this.ForeColor = Color.Red;
            }
            else if (forecolorr == "Blue")
            {
                this.ForeColor= Color.Blue;
            }
            else if (forecolorr == "Green")
            {
                this.ForeColor = Color.Green;
            }


        }
        
    }
}
