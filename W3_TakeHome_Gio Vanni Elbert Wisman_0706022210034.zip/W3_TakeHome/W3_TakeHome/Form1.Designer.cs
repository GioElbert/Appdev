﻿namespace W3_TakeHome
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbNama = new System.Windows.Forms.Label();
            this.lbArtist = new System.Windows.Forms.Label();
            this.txtNama = new System.Windows.Forms.TextBox();
            this.txtArtist = new System.Windows.Forms.TextBox();
            this.checkContent = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbNama
            // 
            this.lbNama.AutoSize = true;
            this.lbNama.Location = new System.Drawing.Point(28, 52);
            this.lbNama.Name = "lbNama";
            this.lbNama.Size = new System.Drawing.Size(50, 16);
            this.lbNama.TabIndex = 0;
            this.lbNama.Text = "Name :";
            // 
            // lbArtist
            // 
            this.lbArtist.AutoSize = true;
            this.lbArtist.Location = new System.Drawing.Point(28, 87);
            this.lbArtist.Name = "lbArtist";
            this.lbArtist.Size = new System.Drawing.Size(115, 16);
            this.lbArtist.TabIndex = 1;
            this.lbArtist.Text = "My Favorite Artist :";
            // 
            // txtNama
            // 
            this.txtNama.Location = new System.Drawing.Point(84, 52);
            this.txtNama.Name = "txtNama";
            this.txtNama.Size = new System.Drawing.Size(261, 22);
            this.txtNama.TabIndex = 5;
            // 
            // txtArtist
            // 
            this.txtArtist.Location = new System.Drawing.Point(149, 87);
            this.txtArtist.Name = "txtArtist";
            this.txtArtist.Size = new System.Drawing.Size(196, 22);
            this.txtArtist.TabIndex = 6;
            // 
            // checkContent
            // 
            this.checkContent.AutoSize = true;
            this.checkContent.Location = new System.Drawing.Point(31, 120);
            this.checkContent.Name = "checkContent";
            this.checkContent.Size = new System.Drawing.Size(18, 17);
            this.checkContent.TabIndex = 7;
            this.checkContent.UseVisualStyleBackColor = true;
            this.checkContent.CheckedChanged += new System.EventHandler(this.checkContent_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 121);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 16);
            this.label1.TabIndex = 8;
            this.label1.Text = "All of the content I put above are true!";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Enabled = false;
            this.btnSubmit.Location = new System.Drawing.Point(31, 152);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(103, 34);
            this.btnSubmit.TabIndex = 9;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(140, 152);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(123, 34);
            this.btnOpen.TabIndex = 10;
            this.btnOpen.Text = "Open Next Form";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkContent);
            this.Controls.Add(this.txtArtist);
            this.Controls.Add(this.txtNama);
            this.Controls.Add(this.lbArtist);
            this.Controls.Add(this.lbNama);
            this.Name = "Form1";
            this.Text = "Main Windows Form";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbNama;
        private System.Windows.Forms.Label lbArtist;
        private System.Windows.Forms.TextBox txtNama;
        private System.Windows.Forms.TextBox txtArtist;
        private System.Windows.Forms.CheckBox checkContent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnOpen;
    }
}

