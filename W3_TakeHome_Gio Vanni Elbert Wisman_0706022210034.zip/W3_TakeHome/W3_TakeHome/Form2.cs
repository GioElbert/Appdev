﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W3_TakeHome
{
    public partial class Form2 : Form
    {
        public string namaa, artistt;
        public string bgcolorrr, foreColorrr;
        public Form2()
        {
            InitializeComponent();
            
        }

        public Form2(string nama, string artist)
        {
            InitializeComponent();
            namaa = nama;
            artistt = artist;
        }



        private void Form2_Load(object sender, EventArgs e)
        {
            Form1 form1 = new Form1(" ", "");
            lbHimyname.Text = "Hi, my name is " + namaa + " and my favorite artist is " + artistt;
            
        }

        private void btnMagic_Click(object sender, EventArgs e)
        {

            if (radioRed.Checked)
            {
                bgcolorrr = "Red";
            }
            else if (radioGreen.Checked)
            {
                bgcolorrr = "Green";

            }
            else if (radioYellow.Checked)
            {
                bgcolorrr = "Yellow";
            }
            else if (radioBlue.Checked)
            {
                bgcolorrr = "Blue";
            }
            else if (radioOrange.Checked)
            {
                bgcolorrr = "Orange";
            }

            if (radioRedText.Checked)
            {
                foreColorrr = "red";
            }
            else if (radioGreenText.Checked)
            {
                foreColorrr = "Green";
            }
            else if (radioBlueText.Checked)
            {
                foreColorrr = "Blue";
            }
            Form1 form1 = new Form1(bgcolorrr, foreColorrr);
            form1.ShowDialog();
            this.Close();


        }

        private void checkAgree2_CheckedChanged(object sender, EventArgs e)
        {
            if ((checkAgree2.Checked && checkChoice2.Checked))
            {
                btnMagic.Enabled = true;

            }
            else
            { 
                btnMagic.Enabled= false;
            }
        }

        private void checkChoice2_CheckedChanged(object sender, EventArgs e)
        {
            if ((checkChoice2.Checked && checkChoice2.Checked))
            {
                btnMagic.Enabled = true;
            }

        }

        private void radioRed_CheckedChanged(object sender, EventArgs e)
        {
            
        }
    }

    
}
